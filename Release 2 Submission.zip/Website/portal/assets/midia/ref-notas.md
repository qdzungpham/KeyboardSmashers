Referência
http://www.eca.usp.br/prof/iazzetta/tutor/acustica/introducao/tabela1.html
